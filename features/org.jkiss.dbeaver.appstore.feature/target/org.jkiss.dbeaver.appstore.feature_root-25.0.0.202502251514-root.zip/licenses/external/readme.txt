Licenses in this directory are applicable to 3rd party drivers which are not included in
the product but which may be downloaded separately after program installation in order to
connect to database servers.
These licenses DO NOT apply to any components of DBeaver or CloudBeaver
products themselves.
